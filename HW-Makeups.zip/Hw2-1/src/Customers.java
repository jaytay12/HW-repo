import java.io.*;
import java.util.Scanner;

public class Customers extends Member{
	
	int nm = 0; //keeps track of # of Members in array.
	int user; //keeps track of who's currently logged in.
	Member [] members;
	Member membr;
	Scanner s = new Scanner(System.in);
	
	//reads file and stores data into array.
	public Customers() throws IOException
	{
		File customer = new File("customers.txt");
		Scanner x = new Scanner(customer);
		members = new Member [20];
		
		while (x.hasNext())
		{
			members[nm] = new Member();
			
			members[nm].id = x.next();
			members[nm].pw = x.next();
			members[nm].fn = x.next();
			members[nm].ln = x.next();
			members[nm].email = x.next();
			nm++;
		}
		
		x.close();
	}
	
	//adds a new Member into array and text file.
	public void customerSignUp() throws IOException
	{
		FileWriter customer = new FileWriter("customers.txt", true); //opens file to add new info and save.
		PrintWriter x = new PrintWriter(customer);
		
		String s1 = " ", s2 = " ";
		members[nm] = new Member();
		
		System.out.print("\nPlease input user id: ");
		members[nm].id = s.next();
		
		do {
			System.out.print("Please input password: ");
			s1 = s.next();
			System.out.print("Please input password again: ");
			s2 = s.next();
			if (!(s1).equals(s2))
				System.out.println("Passwords do not match.");
		} while(!(s1).equals(s2));
		members[nm].pw = s1;
		
		System.out.print("Please input your first name: ");
		members[nm].fn = s.next();
		
		System.out.print("Please input your last name: ");
		members[nm].ln = s.next();
		
		System.out.print("Please input your email: ");
		members[nm].email = s.next();
		
		x.println(members[nm].id + " " + members[nm].pw + " " + members[nm].fn + " " + members[nm].ln + " " + members[nm].email);
		nm++;
		
		x.close();
	}
	
	//deletes Member from array and text file.
	public void deleteCustomer() throws IOException
	{
		int count = -1;
		displayCustomers();
		System.out.print("\nPlease input ID: ");
		String s1 = s.next();
		for (int i = 0; i < nm; i++)
		{
			if (s1.equals(members[i].id))
				count = i;
		}
		if (count > 0) //does not count 0, since 0 is administration.
		{
			displayCustomer(count);
			members[count] = null;
			for (int i = count; i < nm - 1; i++)
			{
				members[i] = members[i + 1];
			}
			nm--;
			
			PrintWriter y = new PrintWriter("customers.txt");//clears text file.
			y.close();
			
			FileWriter customer = new FileWriter("customers.txt", true); //opens file to add new info and save.
			PrintWriter x = new PrintWriter(customer);
			
			for (int i = 0; i < nm; i ++) //adds updated Member array into text file.
			{
				x.println(members[i].id + " " + members[i].pw + " " + members[i].fn + " " + members[i].ln + " " + members[i].email);
			}
			System.out.println("\n" + s1 + " has been deleted!");
			
			x.close();
		}
		else
			System.out.println("ID does not exist.");
	}
	
	//determines if user has access.
	public int customerLogIn()
	{
		int control = 0; //keeps track of if user is administration, customer, or neither.
		System.out.print("\nPlease input your user id: ");
		String s1 = s.next();
		System.out.print("Please input password: ");
		String s2 = s.next();
		
		if ((s1).equals(members[0].id) && (s2).equals(members[0].pw))//if user is the administrator.
		{
			control = 1;
			user = 0;
		}
		else
		{
			for (int i = 0; i < nm; i++)
			{
				if ((s1).equals(members[i].id)) //if user is a customer.
				{
					control = 2; 
					user = i;
				}
				if ((s2).equals(members[i].pw) && control != 2) //if user is neither (incorrect password).
					control = 0;
			}
		}
		
		if (control == 0)
			System.out.println("Incorrect user id or password.");
		
		return control;
	}
	
	//displays all customers.
	public void displayCustomers()
	{
		System.out.println("\nId\t      Password\t      FirstName\t      LastName\t      Email");
		for (int i = 1; i < nm; i++)
		{
			System.out.println(members[i].id + "\t      " + members[i].pw + "\t      " + members[i].fn + "\t      " + members[i].ln + "\t      " + members[i].email);
		}
	}
	
	//displays specified customer.
	public void displayCustomer(int i)
	{
		System.out.println("\nId\t      Password\t      FirstName\t      LastName\t      Email");
		System.out.println(members[i].id + "\t      " + members[i].pw + "\t      " + members[i].fn + "\t      " + members[i].ln + "\t      " + members[i].email);
	}
	
	//updates Member array and text file.
	public void updateCustomersFile() throws IOException 
	{
		int count = -1;//control, if negative does not update file.
		int answer;
		
		displayCustomers();
		System.out.print("\nPlease input ID: ");
		String sId = s.next();
		for (int i = 0; i < nm; i++)
		{
			if ((sId).equals(members[i].id))
				count = i;
		}
		
		if (count > 0)
		{
			Menu menu = new Menu();
			answer = menu.updateUserMenu();
			switch(answer)
			{
			case 1: members[count].setPassword();
					break;
			case 2: members[count].setFName();
					break;
			case 3: members[count].setLName();
					break;
			case 4: members[count].setEmail();
					break;
			}
			
			PrintWriter y = new PrintWriter("customers.txt"); //clears text file.
			y.close();
			
			FileWriter customer = new FileWriter("customers.txt", true); //opens file to add new info and save.
			PrintWriter x = new PrintWriter(customer);
			
			for (int i = 0; i < nm; i++)//adds updated Member array into text file.
			{
				x.println(members[i].id + " " + members[i].pw + " " + members[i].fn + " " + members[i].ln + " " + members[i].email);
			}
			
			x.close();
		}
		else
			System.out.println("ID does not exist.");
		
		displayCustomer(count);
	}
	
	//says good bye to user by name.
	public void goodbyeMsg()
	{
		System.out.println("Bye~ " + members[user].fn + " " + members[user].ln + "!");
	}
}
