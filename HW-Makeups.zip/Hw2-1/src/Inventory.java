import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Inventory extends Cars{
	
	int nc = 0; //keeps track of # of Cars in array.
	Cars [] cars;
	Scanner s = new Scanner(System.in);
	
	//reads file and stores data into Car array.
	public Inventory() throws IOException
	{
		File customer = new File("inventory.txt");
		Scanner x = new Scanner(customer);
		cars = new Cars [20];
		
		while (x.hasNext())
		{
			boolean bn = false;
			cars[nc] = new Cars();
			
			cars[nc].vin = x.next();
			cars[nc].brand = x.next();
			cars[nc].year = x.nextInt();
			cars[nc].mileage = x.nextInt();
			cars[nc].price = x.nextDouble();
			cars[nc].color = s.next().charAt(0);
			String a = s.next();
			if (a.equals("Y"))
				bn = true;
			cars[nc].brandnew = bn;
			nc++;
		}
		
		x.close();
	}
	
	//displays cars if they are brand new.
	public void displayNewInv()
	{
		System.out.println("\nVin\t        Brand\t         Model\t        Year\t        Mileage\t        Price\t        Color\t        New");
		for (int i = 0; i < nc; i++)
		{
			if (cars[i].brandnew == true)
				cars[i].displayCar();
		}
	}
	
	//displays cars that are not brand new.
	public void displayUsedInv()
	{
		System.out.println("\nVin\t        Brand\t         Model\t        Year\t        Mileage\t        Price\t        Color\t        New");
		for (int i = 0; i < nc; i++)
		{
			if (cars[i].brandnew == false)
				cars[i].displayCar();
		}
	}
	
	//displays all cars in inventory.
	public void displayInv()
	{
		System.out.println("\nVin\t        Brand\t         Model\t        Year\t        Mileage\t        Price\t        Color\t        New");
		for (int i = 0; i < nc; i++)
			cars[i].displayCar();
	}
	
	//updates car info in array and adds it into text file.
	public void updateInventoryFile() throws IOException 
	{
		int count = -1;//control, if negative does not update file.
		String bn = " ";
		displayInv();
		System.out.print("\nPlease input VIN: ");
		String answer = s.next();
		for (int i  = 0; i < nc; i++)
		{
			if (answer.equals(cars[i].vin))//compares user input to inventory info.
				count = i;
		}
		//updates array and updates text file.
		if (count >= 0)
		{
			Menu menu = new Menu();
			int choice = menu.updateCarMenu();
			switch(choice)
			{
			case 1: cars[count].setBrand();
					break;
			case 2: cars[count].setModel();
					break;
			case 3: cars[count].setYear();
					break;
			case 4: cars[count].setMileage();
					break;
			case 5: cars[count].setPrice();
					break;
			case 6: cars[count].setColor();
					break;
			}
			
			PrintWriter x = new PrintWriter("inventory.txt"); //clears text file.
			x.close();
			
			FileWriter inventory = new FileWriter("inventory.txt", true); //opens file to add new info and save.
			PrintWriter y = new PrintWriter(inventory);
			
			for (int i = 0; i < nc; i++) //adds updated information to text file.
			{
				if (cars[i].brandnew == true)
					bn = "Y";
				else
					bn = "N";
				
				y.println(cars[i].vin + " " + cars[i].brand + " " + cars[i].model + " " + cars[i].year + " " + cars[i].mileage + " " + cars[i].price + " " + cars[i].color + " " + bn);
			}
			System.out.println("It's updated. Thank you.");
			
			y.close();
		}
		else
			System.out.println("VIN does not exitst.");
	}
	
	//adds new Car info into array and text file.
	public void addNewCar() throws IOException
	{	
		FileWriter inventory = new FileWriter("inventory.txt", true); //opens file to add new info and save.
		PrintWriter x = new PrintWriter(inventory);
		
		cars[nc] = new Cars();
		System.out.print("\nVIN: ");
		cars[nc].vin = s.next();
		
		System.out.print("Brand: ");
		cars[nc].brand = s.next();
		
		System.out.print("Model: ");
		cars[nc].model = s.next();
		
		System.out.print("Year: ");
		cars[nc].year = s.nextInt();
		
		System.out.print("Mileage: ");
		cars[nc].mileage = s.nextInt();
		
		System.out.print("Price: ");
		cars[nc].price = s.nextDouble();
		
		System.out.print("Color: ");
		cars[nc].color = s.next().charAt(0);
		
		System.out.print("New: ");
		String s1 = s.next();
		cars[nc].setNew(s1);
		
		System.out.println("\nVin\t        Brand\t         Model\t        Year\t        Mileage\t        Price\t        Color\t        New");
		cars[nc].displayCar();
		System.out.println("\nSuccessfully this car has been added");
		x.println(cars[nc].vin + " " + cars[nc].brand + " " + cars[nc].model + " " + cars[nc].year + " " + cars[nc].mileage + " " + cars[nc].price + " " + cars[nc].color + " " + s1);
		nc++;
		x.close();
	}
	
	//deletes specified Car.
	public void deleteCar() throws IOException
	{
			int count = -1;
			String bn = " ";
			displayInv();
			System.out.println();
			System.out.print("\nPlease input VIN to delete: ");
			String s1 = s.next();
			System.out.println();
			for (int i = 0; i < nc; i++)//finds car.
			{
				if (s1.equals(cars[i].vin))
					count = i;
			}
			if (count >= 0)//deletes car from array.
			{
				System.out.println("\nVin\t        Brand\t         Model\t        Year\t        Mileage\t        Price\t        Color\t        New");
				cars[count].displayCar();
				
				cars[count] = null;
				nc--;
				
				if (count == nc) //if deleted item is last on the list.
				{
					//do nothing.
				}
				else 
				{
					for (int i = count; i < nc; i++)
					{
						cars[i] = cars[i + 1];
					}
				}
				
				PrintWriter x = new PrintWriter("inventory.txt"); //clears text file.
				x.close();
				
				FileWriter inventory = new FileWriter("inventory.txt", true); //opens file to add new info and save.
				PrintWriter y = new PrintWriter(inventory);
				
				for (int i = 0; i < nc; i++) //adds updated Car array to text file.
				{
					if (cars[i].brandnew == true)
						bn = "Y";
					else
						bn = "N";
					
					y.println(cars[i].vin + " " + cars[i].brand + " " + cars[i].model + " " + cars[i].year + " " + cars[i].mileage + " " + cars[i].price + " " + cars[i].color + " " + bn);
				}
				
				System.out.println("Successfully this car has been deleted.");
				
				y.close();
			}
			else
				System.out.println("VIN does not exist.");
	}
	
	//sorts car by VIN.
	public void sortVIN()
	{
		Cars temp;
		
		for (int i = 0; i < nc; i++)
		{
			int index = i;
			for (int j = i; j < nc; j++)
			{
				int result = cars[j].vin.compareTo(cars[index].vin);
				if (result < 0)
					index = j;
			}
			temp = cars[index];
			cars[index] = cars[i];
			cars[i] = temp;
		}
	}
	
	//sorts car by brand.
	public void sortBrand()
	{
		Cars temp;
		
		for (int i = 0; i < nc; i++)
		{
			int index = i;
			for (int j = i; j < nc; j++)
			{
				int result = cars[j].brand.compareTo(cars[index].brand);
				if (result < 0)
					index = j;
			}
			temp = cars[index];
			cars[index] = cars[i];
			cars[i] = temp;
		}
	}
	
	//sorts car by model.
	public void sortModel()
	{
		Cars temp;
		
		for (int i = 0; i < nc; i++)
		{
			int index = i;
			for (int j = i; j < nc; j++)
			{
				int result = cars[j].model.compareTo(cars[index].model);
				if (result < 0)
					index = j;
			}
			temp = cars[index];
			cars[index] = cars[i];
			cars[i] = temp;
		}
	}
	
	//sorts car by year.
	public void sortYear()
	{	
		Cars temp;
		for (int i = 0; i < nc; i++)
		{
			int index = i;
			for (int j = i; j < nc; j++)
			{
				if (cars[j].year < cars[index].year)
					index = j;
			}
			temp = cars[index];
			cars[index] = cars[i];
			cars[i] = temp;
		}
	}
	
	//sorts car by mileage.
	public void sortMile()
	{
		Cars temp;
		
		for (int i = 0; i < nc; i++)
		{
			int index = i;
			for (int j = i; j < nc; j++)
				if (cars[j].mileage < cars[index].mileage)
					index = j;
			temp = cars[index];
			cars[index] = cars[i];
			cars[i] = temp;
		}
	}
	
	//sorts car by price.
	public void sortPrice()
	{
		Cars temp;
		
		for (int i = 0; i < nc; i++)
		{
			int index = i;
			for (int j = i; j < nc; j++)
				if (cars[j].price < cars[index].price)
					index = j;
			temp = cars[index];
			cars[index] = cars[i];
			cars[i] = temp;
		}
	}
	
	//sorts car by price.
	public void sortColor()
	{
		Cars temp;
		
		for (int i = 0; i < nc; i++)
		{
			int index = i;
			for (int j = i; j < nc; j++)
			{
				if (cars[j].color < cars[index].color)
					index = j;
			}
			temp = cars[index];
			cars[index] = cars[i];
			cars[i] = temp;
		}
	}

}
