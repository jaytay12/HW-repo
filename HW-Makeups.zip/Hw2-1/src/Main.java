import java.io.*;
import java.sql.SQLException;

public class Main {

	public static void main(String[] args) throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
		
		//Hello
		////
		int answer; //keeps track of answers from sub menus.
		int main_answer;//keeps track of answer from the Main Menu.
		Menu menu = new Menu();
		Customers cust = new Customers();
		Inventory inv = new Inventory();
		
		System.out.println("Welcome to Carmax!");
		
		do {
			//Main Menu.
			main_answer = menu.mainMenu();
			if (main_answer == 1)
			{
				//Log In Menu.
				answer = cust.customerLogIn();
				
				//Menu if user works part of Administration.
				if (answer == 1)
				{
					do {
						answer = menu.adminMenu();
						switch(answer)
						{
						case 1: inv.displayInv();
								break;
						case 2: inv.addNewCar();
								break;
						case 3: inv.deleteCar();
								break;
						case 4: inv.updateInventoryFile();
								break;
						case 5: cust.displayCustomers();
								break;
						case 6: cust.customerSignUp();
								break;
						case 7: cust.deleteCustomer();
								break;
						case 8: cust.updateCustomersFile();
								break;
						case 9: break;
						default: System.out.println("Invalid input. Please select from the following.");
									break;
						}
					} while (answer != 9);
				}
				//Menu is user is a Member.
				else if (answer == 2)
				{
					int choice = 0;
					do {
						choice = menu.membrMenu();
					
						if (choice == 1)
						{
							answer = menu.invMenu();
							if (answer == 1)
								inv.displayNewInv();
						
							else
								inv.displayUsedInv();
						}
						else if (choice == 2)
						{
							answer = menu.sortMenu();
							switch(answer)
							{
							case 1: inv.sortVIN();
									inv.displayInv();
									break;
							case 2: inv.sortBrand();
									inv.displayInv();
									break;
							case 3: inv.sortModel();
									inv.displayInv();
									break;
							case 4: inv.sortYear();
									inv.displayInv();
									break;
							case 5: inv.sortMile();
									inv.displayInv();
									break;
							case 6: inv.sortPrice();
									inv.displayInv();
									break;
							case 7: inv.sortColor();
									inv.displayInv();
									break;
							default: System.out.println("Invalid input. Please select from the following.");
										break;
							}
						}
						
					} while (choice != 3);
					
					cust.goodbyeMsg();
				}
			}
			
			else if (main_answer == 2)
			{
				cust.customerSignUp();
			}
			
		} while (main_answer != 3);
		
		System.out.println("Thank you!");
		
	}
}
