import java.util.Scanner;

public class Member {
	String id;
	String pw;
	String fn;
	String ln;
	String email;
	Scanner s = new Scanner(System.in);
	
	public void setId (String x) 
	{
		id = x;
	}
	
	public void setPassword() 
	{	
		System.out.print("Please input new password: ");
		String s1 = s.next();
		System.out.print("Please input password again: ");
		String s2 = s.next();
		if (!s1.equals(s2))
			System.out.println("Passwords do not match.");
		else
			pw = s1;
	}
	
	public void setFName()
	{	
		System.out.print("Please input new first name: ");
		fn = s.next();
	}
	
	public void setLName()
	{
		System.out.print("Please input new last name: ");
		ln = s.next();
	}
	
	public void setEmail()
	{
		System.out.print("Please input new email: ");
		email = s.next();
	}
	
	public String getId ()
	{
		System.out.print("Please input your user id: ");
		String answer = s.next();
		return answer;
	}
	
	public String getPass () 
	{
		System.out.print("Please input password: ");
		String answer = s.next();
		return answer;
	}

}
