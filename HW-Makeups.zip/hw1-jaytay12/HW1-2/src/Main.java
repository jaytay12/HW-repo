import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

Scanner y = new Scanner(System.in);
		
int cpuNum = 0; 
int connectNum = 0; 
int cntrl = 0; 
int cntrlVirus = 0;
int virus = 0; 
int[] compArray = new int[100]; 
int[] virusArray = new int[100]; 

System.out.println("Input: ");
cpuNum = y.nextInt();
connectNum = y.nextInt();


for (int i = 0; i < (connectNum * 2); i++)
{
	compArray[i] = y.nextInt();
}
virusArray[0] = y.nextInt(); 


for (int j = 0; j < (connectNum * 2); j++)
{
	for (int i = 0; i < (connectNum * 2); i++)
	{
		
		if (virusArray[j] == compArray[i] && virusArray[j] != 0)
		{
			compArray[i] = 0; 
			if (i % 2 == 0 && compArray[i + 1] != 0) {
				cntrl++;
				cntrlVirus++;
				virusArray[cntrlVirus] = compArray[i + 1];
			}
			else if (i % 2 != 0 && compArray[i - 1] != 0) {
				cntrl++;
				cntrlVirus++;
				virusArray[cntrlVirus] = compArray[i - 1];
			}
		}
	}
	
	if (j > cntrlVirus)
		break;
}


for (int i = 0; i <= cntrlVirus; i++)
{
	virus = virusArray[i];
	if (virus != 0) {
		for (int j = 0; j <= cntrlVirus; j++)
		{
			
			if (virusArray[j] == virus && i != j) {
				virusArray[j] = 0;
				cntrl--;
			}
		}
	}
}

System.out.println();
System.out.println("Output: \n" + cntrl);
	}

}

