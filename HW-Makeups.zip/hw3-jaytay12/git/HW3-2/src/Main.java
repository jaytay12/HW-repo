import java.util.Scanner;


public class Main {
	
	//adds to current bucket until it reaches its capacity.
	public static int Fill (int cap, int current)
	{
		current = cap;
		return current;
	}
	
	
	
	//empties current bucket.
	public static int Empty (int current)
	{
		current = 0;
		return current;
	}
	
	
	
	
	public static int MoveX (int capY, int y, int x)
	{
		while (y != capY && x != 0)
		{
			y++;
			x--;
		}
				
		return x;
	}
	
	
	
	
	public static int MoveY (int capY, int y, int x)
	{
		while (y != capY && x != 0)
		{
			y++;
			x--;
		}
				
		return y;
	}
	
	
	
	public static int MethodA (int capA, int capB, int desA, int desB, int currentA, int currentB)
	{
				int count = 0;
				
				//if the desired bucketA amount is not 0.
				if (desA != 0) {
					
					if (currentA != desA) {
						
						while (currentA < capA && currentA != desA) //currentA < capA
						{
							if (currentA == capA) {
								currentA = Empty(currentA);
								count++;
							}
							
							if (currentB == 0) {
								currentB = Fill (capB, currentB);
								count++;
							}
							int tempA = currentA, tempB = currentB;
							currentB = MoveX (capA, currentA, currentB);
							currentA = MoveY (capA, tempA, tempB);
							count++;
						}
					}
			
					if (currentA > desA && currentB == desA)
					{
						
						currentA = Empty (currentA);
						count++;
						int tempA = currentA;
						int tempB = currentB;
						currentB = MoveX (capA, currentA, currentB);
						currentA = MoveY (capA, tempA, tempB);
						count++;
					}
				
					if (currentA > desA && currentB != desA)
					{	
						return -1;
					}
				}
				
								if (desB != 0) {
					
					if (desB == capB && currentB != desB) {
						
						currentB = Fill (capB, currentB);
						count++;
					}
			
					if (desB < capB && currentB != desB) {

						while (currentB < capB && currentB != desB) //currentB < capB &&
						{	
							if (currentA == capA) {
								currentA = Empty (currentA);
								count++;
							}
							
							if (currentB == 0) {
								currentB = Fill (capB, currentB);
								count++;
							}
							int tempA = currentA, tempB = currentB;
							currentB = MoveX (capA, currentA, currentB);
							currentA = MoveY (capA, tempA, tempB);
							count++;
						}
					}
				
					if (currentA == desB && currentB != desB) {
						
						currentB = Empty (currentB);
						count++;
						int tempA = currentA, tempB = currentB;
						currentA = MoveX (capB, currentB, currentA);
						currentB = MoveY (capB, tempB, tempA);
						count++;
					}
				}
				
				if (desA == 0 && currentA != 0) {
					
					currentA = Empty (currentA);
					count++;
				}
				
				if (desB == 0 && currentB != 0) {
					
					currentB = Empty (currentB);
					count++;
				}
				
				if (desB != currentB || desA != currentA) {			
					return -1;
				}
				
				return count;
	}
	
	 
	
	
	public static int MethodB (int capA, int capB, int desA, int desB, int currentA, int currentB)
	{
				int count = 0;
				
				//if the desired bucketA amount is not 0.
				if (desB != 0) {
					
					if (currentB != desB) {
				
						while (currentB < capB && currentB != desB) //
						{
							if (currentB == capB) {
								currentB = Empty(currentB);
								count++;
							}
							
							if (currentA == 0) {
								currentA = Fill (capA, currentA);
								count++;
							}
							int tempA = currentA, tempB = currentB;
							currentA = MoveX (capB, currentB, currentA);
							currentB = MoveY (capB, tempB, tempA);
							count++;
						}
					}
				
					if (currentB > desB && currentA == desB)
					{
						currentB = Empty (currentB);
						count++;
						int tempA = currentA;
						int tempB = currentB;
						currentA = MoveX (capB, currentB, currentA);
						currentB = MoveY (capB, tempB, tempA);
						count++;
					}
					
				}
				
				//if the desired bucketB amount is not 0.
				if (desA != 0) {
					
					if (desA == capA && currentA != desA) {
						
						currentA = Fill (capA, currentA);
						count++;
					}
					
					if (currentA != desA) { // 
						
						while (desA < capA && currentA != desA) //
						{

							if (currentB == capB) {
								currentB = Empty(currentB);
								count++;
							}
							
							if (currentA == 0) {
								currentA = Fill (capA, currentA);
								count++;
							}
							int tempA = currentA, tempB = currentB;
							currentA = MoveX (capB, currentB, currentA);
							currentB = MoveY (capB, tempB, tempA);
							count++;
						}
					}
				
					if (currentB == desA && currentA != desA) {
						
						currentA = Empty (currentA);
						count++;
						int tempA = currentA, tempB = currentB;
						currentB = MoveX (capA, currentA, currentB);
						currentA = MoveY (capA, tempA, tempB);
						count++;
					}
				}
				
				if (desA == 0 && currentA != 0) {
					
					currentA = Empty (currentA);
					count++;
				}
					
				if (desB == 0 && currentB != 0) {
					
					currentB = Empty (currentB);
					count++;
				}
					
				if (currentB != desB || currentA != desA)
				{	
					return -1;
				}
				
					return count;
	}
			
	
	
	
	public static int myFunction (int capA, int capB, int desA, int desB, int currentA, int currentB)
	{
				
				if (desA > capA || desB > capB)
					return -1;
				
				else if (desA == 0 && desB == 0)
					return 0;
				
				else if (currentA == desA && currentB == desB)
					return 0;
				
				else {
					
					int result = 0, result2 = 0;
					result = MethodA(capA, capB, desA, desB, currentA, currentB);
					result2 = MethodB(capA, capB, desA, desB, currentA, currentB);
					
					//returns the result that took the least steps and is not a -1.
					if (result2 != -1 && result != -1) {
						if (result < result2)
							return result;
						else
							return result2;
					}
					else {
						if (result != - 1)
							return result;
						else
							return result2;
					}
				}
		}

			
			
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s = new Scanner(System.in);
		int num_case = 0; //number of cases.
		int cA = 0; //capacity of bucket A.
		int cB = 0; //capacity of bucket B.
		int dA = 0; //desired amount for bucket A.
		int dB = 0; //desired amount for bucket B.
		
		System.out.println("Input: ");
		num_case = s.nextInt();
		int [] result = new int [num_case]; //array for containing results for each separate case.
		
		for (int i = 0; i < num_case; i++) {
			cA = s.nextInt();
			
			cB = s.nextInt();
			dA = s.nextInt();
			dB = s.nextInt();
			result[i] = myFunction (cA, cB, dA, dB, 0, 0);
		}
			
		System.out.println("Output: ");
		
		for (int i = 0; i < num_case; i++)
		{
			System.out.println(result[i]);
		}
		
		s.close();
	}
	

}

